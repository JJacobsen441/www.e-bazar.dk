Borgen Monospace

Copyright (c) 2017,
Thor Arisland

Website: www.tcarisland.com
DaFont: www.dafont.com/profile.php?user=972768
Creative Fabrica: https://www.creativefabrica.com/designer/thor/

This font is free for personal use.

For commercial use, please purchase a licence at my Creative Fabrica website at:
https://www.creativefabrica.com/designer/thor/
